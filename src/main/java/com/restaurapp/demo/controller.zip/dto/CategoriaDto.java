// CategoriaDto.java
package com.restaurapp.demo.dto;

public record CategoriaDto(Long id, String nombre, String descripcion) {}
