package com.restaurapp.demo.dto;

public record MesaDto(Long id, String numero) {}
