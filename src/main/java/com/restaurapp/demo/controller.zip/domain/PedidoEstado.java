package com.restaurapp.demo.domain;

public enum PedidoEstado {
    ABIERTO, EN_PREPARACION, LISTO, ENTREGADO, CERRADO, CANCELADO
}
