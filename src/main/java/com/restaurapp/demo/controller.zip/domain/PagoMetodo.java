package com.restaurapp.demo.domain;

public enum PagoMetodo {
    EFECTIVO, TARJETA, QR, TRANSFERENCIA
}
