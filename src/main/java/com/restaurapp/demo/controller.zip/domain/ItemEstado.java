package com.restaurapp.demo.domain;

public enum ItemEstado {
    PENDIENTE, EN_PREPARACION, LISTO
}
