package com.restaurapp.demo.domain;

public enum PagoEstado {
    APLICADO, ANULADO
}
