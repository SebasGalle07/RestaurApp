package com.restaurapp.demo.domain;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/**
 * Persiste el enum Role como string en minúsculas (admin, mesero, cocinero, cajero)
 * y lo lee de vuelta tolerando mayúsculas/minúsculas.
 */
@Converter(autoApply = true)
public class RoleAttributeConverter implements AttributeConverter<Role, String> {

    @Override
    public String convertToDatabaseColumn(Role attribute) {
        return attribute == null ? null : attribute.getValue(); // minúsculas
    }

    @Override
    public Role convertToEntityAttribute(String dbData) {
        return dbData == null ? null : Role.fromValue(dbData);  // tolerante al case
    }
}
