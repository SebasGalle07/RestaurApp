package com.restaurapp.demo.service;

import java.util.List;
import com.restaurapp.demo.dto.MesaDto;

public interface MesaService {
    List<MesaDto> listar();
}
